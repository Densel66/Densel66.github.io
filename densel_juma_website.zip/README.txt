DENSEL JUMA PERSONAL WEBSITE

Files:
- index.html: your website homepage.

Publish free with GitHub Pages:
1. Sign in or create an account at https://github.com/
2. Create a new PUBLIC repository named exactly: YOUR-GITHUB-USERNAME.github.io
3. Upload index.html to the repository's root (top level).
4. Open repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
6. Wait for the deployment. Your address will be https://YOUR-GITHUB-USERNAME.github.io/

Replace YOUR-GITHUB-USERNAME with your actual GitHub username. The address is only an example until you publish.
You can edit index.html later to add your photo and real social links. Do not publish private contact information.
